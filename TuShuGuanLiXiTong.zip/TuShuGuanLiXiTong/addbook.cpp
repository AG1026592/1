#include "addbook.h"
#include "ui_addbook.h"

AddBook::AddBook(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::AddBook)
{
    ui->setupUi(this);
}

AddBook::~AddBook()
{
    delete ui;
}
QString AddBook::checknumber()
{
    return (ui->textEdit_2->toPlainText());
}
QDate AddBook::borrowday()
{
    return m_borrowday;
}
QString AddBook::cardnumber()
{
    return m_strcardnumber;
}
QString AddBook::bookname()
{
    return (ui->textEdit->toPlainText());
}
QString AddBook::booksmumber()
{
    return (ui->textEdit_3->toPlainText());
}

void AddBook::on_buttonBox_accepted()
{

}

