#ifndef ADDBOOK_H
#define ADDBOOK_H
#include"book.h"
#include <QDialog>

namespace Ui {
class AddBook;
}

class AddBook : public QDialog
{
    Q_OBJECT

public:
    explicit AddBook(QWidget *parent = nullptr);
    ~AddBook();
    QString m_strbookname;//书目名称
    bool m_bflag=0;//是否借出
    QString m_strchecknumber;//书登记号
    QDate m_borrowday{1900,1,1}; //借阅日期
    QString checknumber();//书登记号
    QDate borrowday(); //借阅日期
    bool flag();//借出为0未借出为1
    QString m_strcardnumber;//借书证号
    QString cardnumber();//借书证号
    QString bookname();//书目名称
    QString m_strbooksnumber;//书目编号用于创建时锁定书目
    QString booksmumber();//书目编号（用于创建时锁定书目）
private slots:
    void on_buttonBox_accepted();

private:
    Ui::AddBook *ui;
};

#endif // ADDBOOK_H
