#include "addbooks.h"
#include "ui_addbooks.h"

AddBooks::AddBooks(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::AddBooks)
{
    ui->setupUi(this);
}

AddBooks::~AddBooks()
{
    delete ui;
}

int AddBooks::quantity()
{
    QString tNumber=ui->textEdit4->toPlainText();
    int m_nquantity=tNumber.toInt();
    return m_nquantity;
}
QString  AddBooks::booksname()
{
    return (ui->textEdit1->toPlainText());
}

QDate AddBooks::publishday()
{
    return (ui->dateEdit->date());
}

QString  AddBooks::booksnumber()
{
    return (ui->textEdit6->toPlainText());
}

QString  AddBooks::writername()
{
    return (ui->textEdit2->toPlainText());

}

QString  AddBooks::press()
{
    return (ui->textEdit3->toPlainText());
}

void AddBooks::on_buttonBox_accepted()
{

}
