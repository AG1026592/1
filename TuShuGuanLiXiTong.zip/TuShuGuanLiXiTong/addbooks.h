#ifndef ADDBOOKS_H
#define ADDBOOKS_H
#include"books.h"
#include <QDialog>

namespace Ui {//系统自带
class AddBooks;
}

class AddBooks : public QDialog
{
    Q_OBJECT

public:
    explicit AddBooks(QWidget *parent = nullptr);
    ~AddBooks();
    QString m_strpublishday;
    QString m_strquantity;//用于显示库存数量
    QString m_strbookname;//书名
    QString m_strbooknumber;//书编号
    QDate m_publishday{1900,1,1};//出版日期
    QString m_strwritername;//作者名
    QString m_strpress;//出版社
    int m_nquantity;//库存册数
    QString booksname();//书名
    QString booksnumber();//书编号
    QDate publishday();//出版日期
    QString writername();//作者名
    QString press();//出版社
    int quantity();//库存册数
private slots:
    void on_buttonBox_accepted();


private:
    Ui::AddBooks *ui;
};

#endif // ADDBOOKS_H
