#include "book.h"

Book::Book() {}

QString Book::checknumber()
{
    return m_strchecknumber;
}

QDate Book::borrowday()
{
    return m_borrowday;
}
QString Book::cardnumber()
{
    return m_strcardnumber;
}
QString Book::bookname()
{
    return m_strbookname;
}

bool Book::flag()
{
    return m_bflag;
}
QString Book::booksmumber()
{
    return m_strbooksnumber;
}
