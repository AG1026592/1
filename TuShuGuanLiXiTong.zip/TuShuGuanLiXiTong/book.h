#ifndef BOOK_H
#define BOOK_H
#include <QApplication>
#include <QWidget>
#include <QLabel>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QStringList>
#include <QDebug>
#include <QPushButton>
#include <QDialog>
#include <QApplication>
#include <QMainWindow>
#include<QDate>
#include<QDateTime>
#include<QDateEdit>
#include <QTableWidget>
#include <QVBoxLayout>
#include <QPushButton>
#include <QDialog>
#include<QTimer>
#include<QMessageBox>
#include"cardnumber.h"//已经完成
class Book
{
public:
    QString m_strbookname;//书目名称
    bool m_bflag=0;//是否借出
    QString m_strchecknumber;//书登记号
    QDate m_borrowday{1900,1,1}; //借阅日期
    QString checknumber();//书登记号
    QDate borrowday(); //借阅日期
    bool flag();//借出为0未借出为1
    QString m_strcardnumber;//借书证号
    QString cardnumber();//借书证号
    QString bookname();//书目名称
    QString m_strbooksnumber;//书目编号用于创建时锁定书目
    QString booksmumber();//书目编号（用于创建时锁定书目）
    Book();
};

#endif // BOOK_H
