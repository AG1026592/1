#include "books.h"

Books::Books() {}
QString Books::booksname()
{
    return m_strbooksname;
}
QString Books::booksnumber()
{
    return m_strbooksnumber;
}
QDate Books::publishday()
{
    return m_publishday;
}
QString Books::writername()
{
    return m_strwritername;
}
QString Books::press()
{
    return m_strpress;
}
int Books::quantity()
{
    return m_nquantity;
}
