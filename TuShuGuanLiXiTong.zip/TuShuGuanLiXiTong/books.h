#ifndef BOOKS_H
#define BOOKS_H
#include"book.h"
class Books
{
public:
    bool m_bflag=0;//暂时不能删除
    QString m_strpublishday;//出版日期
    QString m_strquantity;//库存册数
    QString m_strbooksname;//书名
    QString m_strbooksnumber;//书目编号
    QDate m_publishday{1900,1,1};//出版日期
    QString m_strwritername;//作者名
    QString m_strpress;//出版社
    int m_nquantity=0;//库存册数
    QVector<Book>m_bookdatagroup;//记录同一个书名下的不同书籍
    QString booksname();//书名
    QString booksnumber();//书目编号
    QDate publishday();//出版日期
    QString writername();//作者名
    QString press();//出版社
    int quantity();//库存册数
    Books();
};

#endif // BOOKS_H
