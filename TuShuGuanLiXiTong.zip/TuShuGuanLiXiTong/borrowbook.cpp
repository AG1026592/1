#include "borrowbook.h"
#include "ui_borrowbook.h"

BorrowBook::BorrowBook(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::BorrowBook)
{
    ui->setupUi(this);
}

BorrowBook::~BorrowBook()
{
    delete ui;
}
QString BorrowBook::bookname()
{
    return (ui->textEdit->toPlainText());
}
QString BorrowBook::checknumber()
{
    return (ui->textEdit_2->toPlainText());
}

void BorrowBook::on_buttonBox_accepted()
{

}

