#ifndef BORROWBOOK_H
#define BORROWBOOK_H
#include"cardnumber.h"//已经完成
#include <QDialog>

namespace Ui {
class BorrowBook;
}

class BorrowBook : public QDialog
{
    Q_OBJECT

public:
    explicit BorrowBook(QWidget *parent = nullptr);
    ~BorrowBook();
    QString bookname();
    QString checknumber();
    QString m_strcardnumber;
private slots:
    void on_buttonBox_accepted();

private:
    Ui::BorrowBook *ui;
};

#endif // BORROWBOOK_H
