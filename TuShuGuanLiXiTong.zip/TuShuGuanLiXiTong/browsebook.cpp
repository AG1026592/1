#include "browsebook.h"
#include "ui_browsebook.h"

BrowseBook::BrowseBook(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::BrowseBook)
{
    ui->setupUi(this);
}

BrowseBook::~BrowseBook()
{
    delete ui;
}

QString BrowseBook::bookname()
{
    return (ui->textEdit->toPlainText());
}
QString BrowseBook::booksnumber()
{
    return (ui->textEdit_2->toPlainText());
}
void BrowseBook::on_buttonBox_accepted()
{

}

