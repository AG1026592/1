#ifndef BROWSEBOOK_H
#define BROWSEBOOK_H

#include <QDialog>

namespace Ui {
class BrowseBook;
}

class BrowseBook : public QDialog
{
    Q_OBJECT

public:
    explicit BrowseBook(QWidget *parent = nullptr);
    ~BrowseBook();
    QString bookname();
    QString booksnumber();
private slots:
    void on_buttonBox_accepted();

private:
    Ui::BrowseBook *ui;
};

#endif // BROWSEBOOK_H
