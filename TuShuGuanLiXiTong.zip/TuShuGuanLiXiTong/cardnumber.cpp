#include "cardnumber.h"
#include "ui_cardnumber.h"

CardNumber::CardNumber(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::CardNumber)
{
    ui->setupUi(this);
}

CardNumber::~CardNumber()
{
    delete ui;
}
QString CardNumber::cardnumber()
{
    return (ui->textEdit->toPlainText());
}

void CardNumber::on_buttonBox_accepted()
{

}

