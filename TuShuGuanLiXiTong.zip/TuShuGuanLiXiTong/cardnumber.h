#ifndef CARDNUMBER_H
#define CARDNUMBER_H

#include <QDialog>

namespace Ui {
class CardNumber;
}

class CardNumber : public QDialog
{
    Q_OBJECT

public:
    explicit CardNumber(QWidget *parent = nullptr);
    ~CardNumber();
    QString cardnumber();//读取借书证号
private slots:
    void on_buttonBox_accepted();

private:
    Ui::CardNumber *ui;
};

#endif // CARDNUMBER_H
