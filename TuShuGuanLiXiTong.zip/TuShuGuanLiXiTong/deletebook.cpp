#include "deletebook.h"
#include "ui_deletebook.h"

DeleteBook::DeleteBook(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::DeleteBook)
{
    ui->setupUi(this);
}

DeleteBook::~DeleteBook()
{
    delete ui;
}

QString DeleteBook::bookname()
{
    return (ui->textEdit->toPlainText());
}

QString DeleteBook::checknumber()
{
    return(ui->textEdit_2->toPlainText());
}

void DeleteBook::on_buttonBox_accepted()
{

}

