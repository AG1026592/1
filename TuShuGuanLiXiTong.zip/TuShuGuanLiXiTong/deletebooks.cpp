#include "deletebooks.h"
#include "ui_deletebooks.h"

DeleteBooks::DeleteBooks(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::DeleteBooks)
{
    ui->setupUi(this);
}

DeleteBooks::~DeleteBooks()
{
    delete ui;
}
QString DeleteBooks::booksname()
{
    return(ui->textEdit->toPlainText());
}
QString DeleteBooks::booksnumber()
{
    return(ui->textEdit_2->toPlainText());
}

void DeleteBooks::on_buttonBox_accepted()
{

}

