#ifndef DELETEBOOKS_H
#define DELETEBOOKS_H

#include <QDialog>

namespace Ui {
class DeleteBooks;
}

class DeleteBooks : public QDialog
{
    Q_OBJECT

public:
    explicit DeleteBooks(QWidget *parent = nullptr);
    ~DeleteBooks();
    QString booksname();//书名
    QString booksnumber();//书编号
private slots:
    void on_buttonBox_accepted();

private:
    Ui::DeleteBooks *ui;
};

#endif // DELETEBOOKS_H
