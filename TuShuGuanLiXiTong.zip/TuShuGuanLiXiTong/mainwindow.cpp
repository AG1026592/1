#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"book.h"//完成
#include"books.h"//完成
#include"addbook.h"//完成
#include"addbooks.h"//完成
#include"deletebook.h"//完成
#include"deletebooks.h"//完成
#include"managebook.h"//完成
#include"managebooks.h"//完成
#include"borrowbook.h"//完成
#include"returnbook.h"//完成
#include"seekbook.h"//完成
#include"seekbooks.h"//完成
#include"browsebook.h"//完成
#include"cardnumber.h"
using namespace std;
//是否可借可以改写成读取库存有就借（如果没有第22行的修改会产生bug）
//是否可借可以改写成遍历Books[i]中的每一本book，如果有book的m_bflag显示可借那么就显示可借，所有与这个显示相同的都可以这么改
//主窗口内有一个Books类的Books向量和一个Book类Book向量Books类里有一个datagroup记录同一名字下的所有书籍
//可以为创建图书时没有写明的书籍自动生成内容（正在用）
int s_nlevel=0;//用于记录已经存入的书目的种类的数目
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::resizeEvent(QResizeEvent *event)
{/*根据窗口大小显示按钮*/
    QMainWindow::resizeEvent(event);
    int x=this->frameGeometry().width();
    int y=this->frameGeometry().height();
    ui->pushButton->setGeometry(0,0,x/4,y/4);//前两个表位置后两个表大小
    ui->pushButton_5->setGeometry(x/4,0,x/4,y/4);
    ui->pushButton_9->setGeometry(x/2,0,x/4,y/4);
    ui->pushButton_2->setGeometry(x*3/4,0,x/4,y/4);
    ui->pushButton_8->setGeometry(0,y/4,x/4,y/4);
    ui->pushButton_10->setGeometry(x/4,y/4,x/4,y/4);
    ui->pushButton_3->setGeometry(x/2,y/4,x/4,y/4);
    ui->pushButton_4->setGeometry(x*3/4,y/4,x/4,y/4);
    ui->pushButton_12->setGeometry(0,y/2,x/4,y/4);
    ui->pushButton_11->setGeometry(x/4,y/2,x/4,y/4);
    ui->pushButton_6->setGeometry(x/2,y/2,x/4,y/4);
    ui->pushButton_7->setGeometry(x*3/4,y/2,x/4,y/4);
    ui->pushButton_13->setGeometry(0,y*3/4,x,y/7);
}

void MainWindow::on_pushButton_clicked()/*创建图书*/
{
    AddBooks dlgSignup(this);
    int ret =dlgSignup.exec();
    if(ret==AddBooks::Accepted)//如果按下ok键
    {
        class Books tempbooks;
        tempbooks.m_strbooksname=dlgSignup.booksname();
        tempbooks.m_publishday=dlgSignup.publishday();
        tempbooks.m_strbooksnumber=dlgSignup.booksnumber();
        tempbooks.m_strpress=dlgSignup.press();
        tempbooks.m_nquantity=dlgSignup.quantity();
        tempbooks.m_strwritername=dlgSignup.writername();//初始化
        QTableWidget *tableWidget = new QTableWidget(1, 7);
        tempbooks.m_strquantity= QString::number(tempbooks.m_nquantity);
        tableWidget->setHorizontalHeaderLabels({"书名","作者名","出版日期","出版社","库存册数","是否可借","书编号"});
        tempbooks.m_strpublishday = tempbooks.m_publishday.toString("yyyy-MM-dd");
        QTableWidgetItem *newItem1 = new QTableWidgetItem(tempbooks.m_strbooksname);
        tableWidget->setItem(0, 0, newItem1);
        QTableWidgetItem *newItem2 = new QTableWidgetItem(tempbooks.m_strwritername);
        tableWidget->setItem(0, 1, newItem2);
        QTableWidgetItem *newItem3 = new QTableWidgetItem(tempbooks.m_strpublishday);
        tableWidget->setItem(0, 2, newItem3);
        QTableWidgetItem *newItem4 = new QTableWidgetItem(tempbooks.m_strpress);
        tableWidget->setItem(0, 3, newItem4);
        QTableWidgetItem *newItem5 = new QTableWidgetItem(tempbooks.m_strquantity);
        tableWidget->setItem(0, 4, newItem5);
        if(tempbooks.m_nquantity==0)//如果没有库存了
        {
            QTableWidgetItem *newItem6 = new QTableWidgetItem("不可借");
            tableWidget->setItem(0, 5, newItem6);
        }
        else if(tempbooks.m_nquantity!=0)//如果有库存
        {
            QTableWidgetItem *newItem6 = new QTableWidgetItem("可借");
            tableWidget->setItem(0, 5, newItem6);
        }
        else
        {
            QTableWidgetItem *newItem6 = new QTableWidgetItem("出错");
            tableWidget->setItem(0, 5, newItem6);
        }
        QTableWidgetItem *newItem7 = new QTableWidgetItem(tempbooks.m_strbooksnumber);
        tableWidget->setItem(0, 6, newItem7);
        tableWidget->show();//显示表格
        srand(time(0));//撒种子

        for(int i=0;i<tempbooks.m_nquantity;i++)
        {
            class Book tempbook;
            tempbook.m_strbookname=tempbooks.m_strbooksname;
            int g_strchecknumber=rand()%1000;
            tempbook.m_strchecknumber=QString::number(g_strchecknumber);//产生随机的书登记号
            tempbook.m_strbooksnumber=tempbooks.m_strbooksnumber;
            tempbook.m_bflag=1;
            tempbook.m_borrowday={1900,1,1};
            tempbooks.m_bookdatagroup.push_back(tempbook);//没设置书登记号不可重复
        }//这个循环自动填充数据可以不用

        Books.push_back(tempbooks);//存入这本图书
        s_nlevel++;
    }
}


void MainWindow::on_pushButton_5_clicked()/*修改图书*/
{
    int j=0;
    ManageBooks dlgSignup(this);
    int ret=dlgSignup.exec();
    class Books tempbooks;
    tempbooks.m_strbooksname=dlgSignup.booksname();
    tempbooks.m_strbooksnumber=dlgSignup.booksnumber();
    if(ret==ManageBooks::Accepted)//按下ok键
    {
        QTableWidget *tableWidget = new QTableWidget(0, 7);
        int m=0;//计数
        for(int i=0;i<Books.size();i++)//遍历Books向量找与要改的书同名的书
        {
            if(Books[i].m_strbooksname==tempbooks.m_strbooksname&&Books[i].m_strbooksnumber==tempbooks.m_strbooksnumber)//如果同名//并且同书目编号
            {
                tableWidget->setHorizontalHeaderLabels({"书名","作者名","出版日期","出版社","库存册数","是否可借","书编号"});
                j++;//感觉能改
                j= tableWidget->rowCount();
                tableWidget->insertRow(j);
                QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_strbooksname);
                tableWidget->setItem(j, 0, newItem1);
                QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                tableWidget->setItem(j, 1, newItem2);
                QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                tableWidget->setItem(j, 2, newItem3);
                QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                tableWidget->setItem(j, 3, newItem4);
                Books[i].m_strquantity= QString::number(Books[i].m_nquantity);
                QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_strquantity);
                tableWidget->setItem(j, 4, newItem5);
                int k=0;
                for(int i=0;i<Books.size();i++)
                {
                    for(int j=0;j<Books[i].m_bookdatagroup.size();j++)
                    {
                        if(Books[i].m_bookdatagroup[j].m_bflag==1)
                        {
                            k++;
                            break;
                        }
                        else
                        {
                        }
                    }
                }//判断是否有能借的书
                if(k!=0)
                {
                    QTableWidgetItem *newItem6 = new QTableWidgetItem("可借");
                    tableWidget->setItem(0, 5, newItem6);
                }
                else
                {
                    QTableWidgetItem *newItem6 = new QTableWidgetItem("不可借");
                    tableWidget->setItem(0, 5, newItem6);
                }
                /*if(tempbooks.m_nquantity==0)//如果没有库存了
        {
            QTableWidgetItem *newItem6 = new QTableWidgetItem("不可借");
            tableWidget->setItem(0, 5, newItem6);
        }
        else if(tempbooks.m_nquantity!=0)//如果有库存
        {
            QTableWidgetItem *newItem6 = new QTableWidgetItem("可借");
            tableWidget->setItem(0, 5, newItem6);
        }
        else
        {
            QTableWidgetItem *newItem6 = new QTableWidgetItem("出错");
            tableWidget->setItem(0, 5, newItem6);
        }*/
                QTableWidgetItem *newItem7 = new QTableWidgetItem(Books[i].m_strbooksnumber);
                tableWidget->setItem(j, 6, newItem7);
                tableWidget->show();
                AddBooks tempbooks2;
                AddBooks dlgSignup(this);//显示要修改成什么样
                int ret2 =dlgSignup.exec();
                if(ret2==AddBooks::Accepted)//按下ok后开始把新数据输入进去
                {
                    if(Books[i].m_nquantity!=dlgSignup.quantity())
                    {
                        QMessageBox messageBox;//弹一个窗口显示文字
                        messageBox.setWindowTitle("结果");
                        messageBox.setText("不可以修改数目");
                        messageBox.exec();
                    }
                    else
                    {
                        Books[i].m_strbooksname=dlgSignup.booksname();
                        Books[i].m_publishday=dlgSignup.publishday();
                        Books[i].m_strbooksnumber=dlgSignup.booksnumber();
                        Books[i].m_strpress=dlgSignup.press();
                        Books[i].m_strwritername=dlgSignup.writername();//修改信息
                    }
                    m++;
                    for(int j=0;j<Books[i].m_bookdatagroup.size();j++)
                    {
                        Books[i].m_bookdatagroup[j].m_strbooksnumber=dlgSignup.booksnumber();
                        Books[i].m_bookdatagroup[j].m_strbookname=dlgSignup.booksname();//修改该图书类下所有的书籍，
                    }
                }
            }
            else
            {

            }
        }
        delete tableWidget;
        if(m==0)//如果没有匹配的书
        {
            QMessageBox messageBox;//弹一个窗口显示文字
            messageBox.setWindowTitle("结果");
            messageBox.setText("请确认信息正确");
            messageBox.exec();
        }
    }
}


void MainWindow::on_pushButton_9_clicked()/*删除图书*/
{
    DeleteBooks dlgSignup(this);
    class Books tempbooks;
    int ret =dlgSignup.exec();
    if(ret==DeleteBooks::Accepted)
    {
        int m=0;//用于计数观察是否有搜索到的
        tempbooks.m_strbooksname=dlgSignup.booksname();
        tempbooks.m_strbooksnumber=dlgSignup.booksnumber();
        for(int i=0;i<Books.size();i++)//遍历Books向量找到与要删除的图书同名或者同书目编号的然后移除该内容
        {
            if((tempbooks.m_strbooksname==Books[i].m_strbooksname)&&(tempbooks.m_strbooksnumber==Books[i].m_strbooksnumber))//这里应该用&&而非||因为书目编号是唯一的
            {
                Books.remove(i);//移除这个对象
                m++;
                break;//离开循环
            }

        }
        if(m==0)
        {
            QMessageBox messageBox;//弹一个窗口显示文字
            messageBox.setWindowTitle("结果");
            messageBox.setText("请确认信息正确");
            messageBox.exec();
        }
        s_nlevel--;//存有的书目类型数减少一个
    }
}


void MainWindow::on_pushButton_2_clicked()/*创建书籍*/
{
    AddBook dlgSignup(this);
    int ret=dlgSignup.exec();
    class Book tempbook;
    tempbook.m_strbookname=dlgSignup.bookname();
    tempbook.m_strchecknumber=dlgSignup.checknumber();
    tempbook.m_strbooksnumber=dlgSignup.booksmumber();
    if(ret==AddBook::Accepted)
    {
        for(int i=0;i<Books.size();i++)//在所有图书中寻找
        {
            if(tempbook.m_strbookname==Books[i].m_strbooksname&&tempbook.m_strbooksnumber==Books[i].m_strbooksnumber)//如果书名相同//并且书目编号相同
            {
                tempbook.m_borrowday={1900,1,1};//初始化
                tempbook.m_bflag=1;
                tempbook.m_strcardnumber=0;
                Books[i].m_nquantity++;//多存一本书
                Books[i].m_bookdatagroup.push_back(tempbook);//向同一本书的数据集的队尾添加上这个Book
            }
            else
            {

            }
        }
    }
}


void MainWindow::on_pushButton_8_clicked()/*修改书籍*/
{
    ManageBook dlgSignup(this);
    int ret=dlgSignup.exec();
    class Book tempbook;
    tempbook.m_strbookname=dlgSignup.bookname();
    tempbook.m_strchecknumber=dlgSignup.checknumber();
    if(ret==ManageBook::Accepted)
    {
        int m=0;//计数//循环内比较可能有问题导致无法正确修改
        for(int i=0;i<Books.size();i++)//遍历Books向量
        {
            if(Books[i].m_strbooksname==tempbook.m_strbookname)//如果有一本书名字和要改的一样
            {
                for(int j=0;j<Books[i].m_bookdatagroup.size();j++)//遍历Books[i]的登记号数据集中的应该添加一个登记号的匹配
                {
                    if(Books[i].m_bookdatagroup[j].m_strchecknumber==tempbook.m_strchecknumber)
                    {
                        AddBook dlgSignup(this);
                        int ret=dlgSignup.exec();
                        AddBook tempbook2;
                        if(ret==AddBook::Accepted)
                        {
                            if(dlgSignup.bookname()!=Books[i].m_bookdatagroup[j].m_strbookname||Books[i].m_strbooksnumber!=dlgSignup.booksmumber())
                            {
                                QMessageBox messageBox;//弹一个窗口显示文字
                                messageBox.setWindowTitle("结果");
                                messageBox.setText("不可以修改登记号或者书籍名");
                                messageBox.exec();
                            }
                            else
                            {
                            tempbook2.m_strchecknumber=dlgSignup.checknumber();
                            Books[i].m_bookdatagroup[j].m_strcardnumber=0;//借书证号默认为0
                            Books[i].m_bookdatagroup[j].m_strchecknumber=tempbook2.m_strchecknumber;
                            Books[i].m_bookdatagroup[j].m_borrowday={1900,1,1};//借书时间默认
                            }
                            m++;
                        }
                    }
                    else
                    {
                    }
                }
            }
            else
            {

            }
        }
        if(m==0)
        {
            QMessageBox messageBox;//弹一个窗口显示文字
            messageBox.setWindowTitle("结果");
            messageBox.setText("请确认信息正确");
            messageBox.exec();
        }
    }
}


void MainWindow::on_pushButton_10_clicked()/*删除书籍*/
{
    DeleteBook dlgSignup(this);
    int ret=dlgSignup.exec();
    class Book tempbook;
    if(ret==DeleteBook::Accepted)
    {
        int m=0;//用于计数看是否有被搜到的书
        tempbook.m_strbookname=dlgSignup.bookname();
        tempbook.m_strchecknumber=dlgSignup.checknumber();//进行匹配
        for(int i=0;i<Books.size();i++)
        {
            for(int j=0;j<Books[i].m_bookdatagroup.size();j++)//把所有书籍都搜索一遍
            {
                if((tempbook.m_strbookname==Books[i].m_bookdatagroup[j].m_strbookname)&&(tempbook.m_strchecknumber==Books[i].m_bookdatagroup[j].m_strchecknumber)&&Books[i].m_bookdatagroup[j].m_bflag!=0)
                {//如果出现书登记号匹配
                    Books[i].m_bookdatagroup.remove(j);//删除该对象
                    Books[i].m_nquantity--;//书目减少一本
                    m++;
                    break;//应该搜索完所有以后再弹出错误
                }
            }
        }
        if(m==0)
        {
            QMessageBox messageBox;//弹一个窗口显示文字
            messageBox.setWindowTitle("结果");
            messageBox.setText("请确认信息正确");
            messageBox.exec();
        }
    }
}


void MainWindow::on_pushButton_3_clicked()/*浏览图书*/
{
    AddBooks dlgSignup(this);
    QTableWidget *tableWidget = new QTableWidget(s_nlevel, 7);//有多少种存入的书就多少行
    tableWidget->setHorizontalHeaderLabels({"书名","作者名","出版日期","出版社","库存册数","是否可借","书编号"});
    for(int i=0;i<Books.size();i++)//每一行都以同样的方式产生数据
    {
        QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_strbooksname);
        tableWidget->setItem(i, 0, newItem1);
        QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
        tableWidget->setItem(i, 1, newItem2);
        QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
        tableWidget->setItem(i, 2, newItem3);
        QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
        tableWidget->setItem(i, 3, newItem4);
        Books[i].m_strquantity= QString::number(Books[i].m_nquantity);
        QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_strquantity);
        tableWidget->setItem(i, 4, newItem5);
        int k=0;
        for(int j=0;j<Books[i].m_bookdatagroup.size();j++)
        {
            if(Books[i].m_bookdatagroup[j].m_bflag==1)
            {
                k++;
                break;
            }
            else
            {
            }
        }
        if(k!=0)
        {
            QTableWidgetItem *newItem6 = new QTableWidgetItem("可借");
            tableWidget->setItem(i, 5, newItem6);
        }
        else
        {
            QTableWidgetItem *newItem6 = new QTableWidgetItem("不可借");
            tableWidget->setItem(i, 5, newItem6);
        }//检查有没有可用的书登记号
        /*if(tempbooks.m_nquantity==0)//如果没有库存了
        {
            QTableWidgetItem *newItem6 = new QTableWidgetItem("不可借");
            tableWidget->setItem(0, 5, newItem6);
        }
        else if(tempbooks.m_nquantity!=0)//如果有库存
        {
            QTableWidgetItem *newItem6 = new QTableWidgetItem("可借");
            tableWidget->setItem(0, 5, newItem6);
        }
        else
        {
            QTableWidgetItem *newItem6 = new QTableWidgetItem("出错");
            tableWidget->setItem(0, 5, newItem6);
        }*/
        QTableWidgetItem *newItem7 = new QTableWidgetItem(Books[i].m_strbooksnumber);
        tableWidget->setItem(i, 6, newItem7);//完成了图书的浏览
    }
    tableWidget->show();
}


void MainWindow::on_pushButton_4_clicked()/*查询图书*/
{
    int j=0;//记录符合要求的书本的个数
    SeekBooks dlgSignup(this);
    int ret=dlgSignup.exec();
    class Books tempbooks;
    tempbooks.m_strbooksname=dlgSignup.booksname();
    tempbooks.m_strbooksnumber=dlgSignup.booksnumber();
    tempbooks.m_strpress=dlgSignup.press();
    tempbooks.m_strwritername=dlgSignup.writername();//读取所有的输入的信息
    if(ret==SeekBooks::Accepted)
    {
        QTableWidget *tableWidget = new QTableWidget(0, 7);//产生一个0行7列的表格，逐个添加行，有满足条件的就添加一行
        tableWidget->setHorizontalHeaderLabels({"书名","作者名","出版日期","出版社","库存册数","是否可借","书编号"});
        if(tempbooks.m_strbooksname!="")//四项都输入到四项都不输入总共16种情况十五种能查出
        {
            if(tempbooks.m_strpress!="")
            {
                if(tempbooks.m_strwritername!="")
                {
                    if(tempbooks.m_strbooksnumber!="")
                    {
                        //根据四项查询
                        for(int i=0;i<Books.size();i++)//遍历Books寻找符合条件的书
                        {
                            if(tempbooks.m_strbooksname==Books[i].m_strbooksname&&tempbooks.m_strpress==Books[i].m_strpress&&tempbooks.m_strbooksnumber==Books[i].m_strbooksnumber&&tempbooks.m_strwritername==Books[i].m_strwritername)
                            {
                                Books[i].m_strquantity= QString::number(Books[i].m_nquantity);
                                tableWidget->insertRow(j);
                                Books[i].m_strpublishday = Books[i].m_publishday.toString("yyyy-MM-dd");
                                 QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_strbooksname);
                                tableWidget->setItem(0, 0, newItem1);
                                QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                                tableWidget->setItem(0, 1, newItem2);
                                QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                                tableWidget->setItem(0, 2, newItem3);
                                QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                                tableWidget->setItem(0, 3, newItem4);
                                QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_strquantity);
                                tableWidget->setItem(0, 4, newItem5);
                                int k=0;
                                for(int i=0;i<Books.size();i++)
                                {
                                    for(int j=0;j<Books[i].m_bookdatagroup.size();j++)
                                    {
                                        if(Books[i].m_bookdatagroup[j].m_bflag==1)
                                        {
                                            k++;
                                            break;
                                        }
                                        else
                                        {
                                        }
                                    }
                                }
                                if(k!=0)
                                {
                                    QTableWidgetItem *newItem6 = new QTableWidgetItem("可借");
                                    tableWidget->setItem(0, 5, newItem6);
                                }
                                else
                                {
                                    QTableWidgetItem *newItem6 = new QTableWidgetItem("不可借");
                                    tableWidget->setItem(0, 5, newItem6);
                                }
                                QTableWidgetItem *newItem7 = new QTableWidgetItem(Books[i].m_strbooksnumber);
                                tableWidget->setItem(0, 6, newItem7);
                            }
                        }
                    }
                    else
                    {
                        //根据除了书目编号以外的三项查询
                        for(int i=0;i<Books.size();i++)//遍历Books寻找符合条件的书
                        {
                            if(tempbooks.m_strbooksname==Books[i].m_strbooksname&&tempbooks.m_strpress==Books[i].m_strpress&&tempbooks.m_strwritername==Books[i].m_strwritername)
                            {
                                Books[i].m_strquantity= QString::number(Books[i].m_nquantity);
                                tableWidget->insertRow(j);
                                Books[i].m_strpublishday = Books[i].m_publishday.toString("yyyy-MM-dd");
                                QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_strbooksname);
                                tableWidget->setItem(0, 0, newItem1);
                                QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                                tableWidget->setItem(0, 1, newItem2);
                                QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                                tableWidget->setItem(0, 2, newItem3);
                                QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                                tableWidget->setItem(0, 3, newItem4);
                                QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_strquantity);
                                tableWidget->setItem(0, 4, newItem5);
                                int k=0;
                                for(int i=0;i<Books.size();i++)
                                {
                                    for(int j=0;j<Books[i].m_bookdatagroup.size();j++)
                                    {
                                        if(Books[i].m_bookdatagroup[j].m_bflag==1)
                                        {
                                            k++;
                                            break;
                                        }
                                        else
                                        {
                                        }
                                    }
                                }
                                if(k!=0)
                                {
                                    QTableWidgetItem *newItem6 = new QTableWidgetItem("可借");
                                    tableWidget->setItem(0, 5, newItem6);
                                }
                                else
                                {
                                    QTableWidgetItem *newItem6 = new QTableWidgetItem("不可借");
                                    tableWidget->setItem(0, 5, newItem6);
                                }
                                QTableWidgetItem *newItem7 = new QTableWidgetItem(Books[i].m_strbooksnumber);
                                tableWidget->setItem(0, 6, newItem7);
                            }
                        }
                    }
                }
                else if(tempbooks.m_strbooksnumber!="")
                {
                    //根据除了作者名以外的三项查询
                    for(int i=0;i<Books.size();i++)//遍历Books寻找符合条件的书
                    {
                        if(tempbooks.m_strbooksname==Books[i].m_strbooksname&&tempbooks.m_strpress==Books[i].m_strpress&&tempbooks.m_strbooksnumber==Books[i].m_strbooksnumber)
                        {
                            Books[i].m_strquantity= QString::number(Books[i].m_nquantity);
                            tableWidget->insertRow(j);
                            Books[i].m_strpublishday = Books[i].m_publishday.toString("yyyy-MM-dd");
                            QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_strbooksname);
                            tableWidget->setItem(0, 0, newItem1);
                            QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                            tableWidget->setItem(0, 1, newItem2);
                            QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                            tableWidget->setItem(0, 2, newItem3);
                            QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                            tableWidget->setItem(0, 3, newItem4);
                            QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_strquantity);
                            tableWidget->setItem(0, 4, newItem5);
                            int k=0;
                            for(int i=0;i<Books.size();i++)
                            {
                                for(int j=0;j<Books[i].m_bookdatagroup.size();j++)
                                {
                                    if(Books[i].m_bookdatagroup[j].m_bflag==1)
                                    {
                                        k++;
                                        break;
                                    }
                                    else
                                    {
                                    }
                                }
                            }
                            if(k!=0)
                            {
                                QTableWidgetItem *newItem6 = new QTableWidgetItem("可借");
                                tableWidget->setItem(0, 5, newItem6);
                            }
                            else
                            {
                                QTableWidgetItem *newItem6 = new QTableWidgetItem("不可借");
                                tableWidget->setItem(0, 5, newItem6);
                            }
                            QTableWidgetItem *newItem7 = new QTableWidgetItem(Books[i].m_strbooksnumber);
                            tableWidget->setItem(0, 6, newItem7);
                        }
                    }
                }
                else
                {
                    //根据出版社和书名查询
                    for(int i=0;i<Books.size();i++)//遍历Books寻找符合条件的书
                    {
                        if(tempbooks.m_strbooksname==Books[i].m_strbooksname&&tempbooks.m_strpress==Books[i].m_strpress)
                        {
                            Books[i].m_strquantity= QString::number(Books[i].m_nquantity);
                            tableWidget->insertRow(j);
                            Books[i].m_strpublishday = Books[i].m_publishday.toString("yyyy-MM-dd");
                            QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_strbooksname);
                            tableWidget->setItem(0, 0, newItem1);
                            QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                            tableWidget->setItem(0, 1, newItem2);
                            QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                            tableWidget->setItem(0, 2, newItem3);
                            QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                            tableWidget->setItem(0, 3, newItem4);
                            QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_strquantity);
                            tableWidget->setItem(0, 4, newItem5);
                            int k=0;
                            for(int i=0;i<Books.size();i++)
                            {
                                for(int j=0;j<Books[i].m_bookdatagroup.size();j++)
                                {
                                    if(Books[i].m_bookdatagroup[j].m_bflag==1)
                                    {
                                        k++;
                                        break;
                                    }
                                    else
                                    {
                                    }
                                }
                            }
                            if(k!=0)
                            {
                                QTableWidgetItem *newItem6 = new QTableWidgetItem("可借");
                                tableWidget->setItem(0, 5, newItem6);
                            }
                            else
                            {
                                QTableWidgetItem *newItem6 = new QTableWidgetItem("不可借");
                                tableWidget->setItem(0, 5, newItem6);
                            }
                            QTableWidgetItem *newItem7 = new QTableWidgetItem(Books[i].m_strbooksnumber);
                            tableWidget->setItem(0, 6, newItem7);
                        }
                    }
                }
            }
            else if(tempbooks.m_strwritername!="")
            {
                if(tempbooks.m_strbooksnumber!="")
                {
                    //根据除了出版社以外的三项查询
                    for(int i=0;i<Books.size();i++)//遍历Books寻找符合条件的书
                    {
                        if(tempbooks.m_strbooksname==Books[i].m_strbooksname&&tempbooks.m_strbooksnumber==Books[i].m_strbooksnumber&&tempbooks.m_strwritername==Books[i].m_strwritername)
                        {
                            Books[i].m_strquantity= QString::number(Books[i].m_nquantity);
                            tableWidget->insertRow(j);
                            Books[i].m_strpublishday = Books[i].m_publishday.toString("yyyy-MM-dd");
                            QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_strbooksname);
                            tableWidget->setItem(0, 0, newItem1);
                            QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                            tableWidget->setItem(0, 1, newItem2);
                            QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                            tableWidget->setItem(0, 2, newItem3);
                            QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                            tableWidget->setItem(0, 3, newItem4);
                            QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_strquantity);
                            tableWidget->setItem(0, 4, newItem5);
                            int k=0;
                            for(int i=0;i<Books.size();i++)
                            {
                                for(int j=0;j<Books[i].m_bookdatagroup.size();j++)
                                {
                                    if(Books[i].m_bookdatagroup[j].m_bflag==1)
                                    {
                                        k++;
                                        break;
                                    }
                                    else
                                    {
                                    }
                                }
                            }
                            if(k!=0)
                            {
                                QTableWidgetItem *newItem6 = new QTableWidgetItem("可借");
                                tableWidget->setItem(0, 5, newItem6);
                            }
                            else
                            {
                                QTableWidgetItem *newItem6 = new QTableWidgetItem("不可借");
                                tableWidget->setItem(0, 5, newItem6);
                            }
                            QTableWidgetItem *newItem7 = new QTableWidgetItem(Books[i].m_strbooksnumber);
                            tableWidget->setItem(0, 6, newItem7);
                        }
                    }
                }
                else
                {
                    //根据作者名和书名查询
                    for(int i=0;i<Books.size();i++)//遍历Books寻找符合条件的书
                    {
                        if(tempbooks.m_strbooksname==Books[i].m_strbooksname&&tempbooks.m_strwritername==Books[i].m_strwritername)
                        {
                            Books[i].m_strquantity= QString::number(Books[i].m_nquantity);
                            tableWidget->insertRow(j);
                            Books[i].m_strpublishday = Books[i].m_publishday.toString("yyyy-MM-dd");
                            QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_strbooksname);
                            tableWidget->setItem(0, 0, newItem1);
                            QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                            tableWidget->setItem(0, 1, newItem2);
                            QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                            tableWidget->setItem(0, 2, newItem3);
                            QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                            tableWidget->setItem(0, 3, newItem4);
                            QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_strquantity);
                            tableWidget->setItem(0, 4, newItem5);
                            int k=0;
                            for(int i=0;i<Books.size();i++)
                            {
                                for(int j=0;j<Books[i].m_bookdatagroup.size();j++)
                                {
                                    if(Books[i].m_bookdatagroup[j].m_bflag==1)
                                    {
                                        k++;
                                        break;
                                    }
                                    else
                                    {
                                    }
                                }
                            }
                            if(k!=0)
                            {
                                QTableWidgetItem *newItem6 = new QTableWidgetItem("可借");
                                tableWidget->setItem(0, 5, newItem6);
                            }
                            else
                            {
                                QTableWidgetItem *newItem6 = new QTableWidgetItem("不可借");
                                tableWidget->setItem(0, 5, newItem6);
                            }
                            QTableWidgetItem *newItem7 = new QTableWidgetItem(Books[i].m_strbooksnumber);
                            tableWidget->setItem(0, 6, newItem7);
                        }
                    }
                }
            }
            else
            {
                if(tempbooks.m_strbooksnumber!="")
                {
                    //根据书目遍号和书名查询
                    for(int i=0;i<Books.size();i++)//遍历Books寻找符合条件的书
                    {
                        if(tempbooks.m_strbooksname==Books[i].m_strbooksname&&tempbooks.m_strbooksnumber==Books[i].m_strbooksnumber)
                        {
                            Books[i].m_strquantity= QString::number(Books[i].m_nquantity);
                            tableWidget->insertRow(j);
                            Books[i].m_strpublishday = Books[i].m_publishday.toString("yyyy-MM-dd");
                            QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_strbooksname);
                            tableWidget->setItem(0, 0, newItem1);
                            QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                            tableWidget->setItem(0, 1, newItem2);
                            QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                            tableWidget->setItem(0, 2, newItem3);
                            QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                            tableWidget->setItem(0, 3, newItem4);
                            QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_strquantity);
                            tableWidget->setItem(0, 4, newItem5);
                            int k=0;
                            for(int i=0;i<Books.size();i++)
                            {
                                for(int j=0;j<Books[i].m_bookdatagroup.size();j++)
                                {
                                    if(Books[i].m_bookdatagroup[j].m_bflag==1)
                                    {
                                        k++;
                                        break;
                                    }
                                    else
                                    {
                                    }
                                }
                            }
                            if(k!=0)
                            {
                                QTableWidgetItem *newItem6 = new QTableWidgetItem("可借");
                                tableWidget->setItem(0, 5, newItem6);
                            }
                            else
                            {
                                QTableWidgetItem *newItem6 = new QTableWidgetItem("不可借");
                                tableWidget->setItem(0, 5, newItem6);
                            }
                            QTableWidgetItem *newItem7 = new QTableWidgetItem(Books[i].m_strbooksnumber);
                            tableWidget->setItem(0, 6, newItem7);
                        }
                    }
                }
                else
                {
                    //根据书名查询
                    for(int i=0;i<Books.size();i++)//遍历Books寻找符合条件的书
                    {
                        if(tempbooks.m_strbooksname==Books[i].m_strbooksname)
                        {
                            Books[i].m_strquantity= QString::number(Books[i].m_nquantity);
                            tableWidget->insertRow(j);
                            Books[i].m_strpublishday = Books[i].m_publishday.toString("yyyy-MM-dd");
                            QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_strbooksname);
                            tableWidget->setItem(0, 0, newItem1);
                            QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                            tableWidget->setItem(0, 1, newItem2);
                            QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                            tableWidget->setItem(0, 2, newItem3);
                            QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                            tableWidget->setItem(0, 3, newItem4);
                            QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_strquantity);
                            tableWidget->setItem(0, 4, newItem5);
                            int k=0;
                            for(int i=0;i<Books.size();i++)
                            {
                                for(int j=0;j<Books[i].m_bookdatagroup.size();j++)
                                {
                                    if(Books[i].m_bookdatagroup[j].m_bflag==1)
                                    {
                                        k++;
                                        break;
                                    }
                                    else
                                    {
                                    }
                                }
                            }
                            if(k!=0)
                            {
                                QTableWidgetItem *newItem6 = new QTableWidgetItem("可借");
                                tableWidget->setItem(0, 5, newItem6);
                            }
                            else
                            {
                                QTableWidgetItem *newItem6 = new QTableWidgetItem("不可借");
                                tableWidget->setItem(0, 5, newItem6);
                            }
                            QTableWidgetItem *newItem7 = new QTableWidgetItem(Books[i].m_strbooksnumber);
                            tableWidget->setItem(0, 6, newItem7);
                        }
                    }
                }
            }
        }
        else
        {
            if(tempbooks.m_strpress!="")
            {
                if(tempbooks.m_strwritername!="")
                {
                    if(tempbooks.m_strbooksnumber!="")
                    {
                        //根据除了书名以外的三项查询
                        for(int i=0;i<Books.size();i++)//遍历Books寻找符合条件的书
                        {
                            if(tempbooks.m_strpress==Books[i].m_strpress&&tempbooks.m_strbooksnumber==Books[i].m_strbooksnumber&&tempbooks.m_strwritername==Books[i].m_strwritername)
                            {
                                Books[i].m_strquantity= QString::number(Books[i].m_nquantity);
                                tableWidget->insertRow(j);
                                Books[i].m_strpublishday = Books[i].m_publishday.toString("yyyy-MM-dd");
                                QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_strbooksname);
                                tableWidget->setItem(0, 0, newItem1);
                                QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                                tableWidget->setItem(0, 1, newItem2);
                                QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                                tableWidget->setItem(0, 2, newItem3);
                                QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                                tableWidget->setItem(0, 3, newItem4);
                                QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_strquantity);
                                tableWidget->setItem(0, 4, newItem5);
                                int k=0;
                                for(int i=0;i<Books.size();i++)
                                {
                                    for(int j=0;j<Books[i].m_bookdatagroup.size();j++)
                                    {
                                        if(Books[i].m_bookdatagroup[j].m_bflag==1)
                                        {
                                            k++;
                                            break;
                                        }
                                        else
                                        {
                                        }
                                    }
                                }
                                if(k!=0)
                                {
                                    QTableWidgetItem *newItem6 = new QTableWidgetItem("可借");
                                    tableWidget->setItem(0, 5, newItem6);
                                }
                                else
                                {
                                    QTableWidgetItem *newItem6 = new QTableWidgetItem("不可借");
                                    tableWidget->setItem(0, 5, newItem6);
                                }
                                QTableWidgetItem *newItem7 = new QTableWidgetItem(Books[i].m_strbooksnumber);
                                tableWidget->setItem(0, 6, newItem7);
                            }
                        }
                    }
                    else
                    {
                        //根据出版社和作者名查询
                        for(int i=0;i<Books.size();i++)//遍历Books寻找符合条件的书
                        {
                            if(tempbooks.m_strpress==Books[i].m_strpress&&tempbooks.m_strwritername==Books[i].m_strwritername)
                            {
                                Books[i].m_strquantity= QString::number(Books[i].m_nquantity);
                                tableWidget->insertRow(j);
                                Books[i].m_strpublishday = Books[i].m_publishday.toString("yyyy-MM-dd");
                                QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_strbooksname);
                                tableWidget->setItem(0, 0, newItem1);
                                QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                                tableWidget->setItem(0, 1, newItem2);
                                QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                                tableWidget->setItem(0, 2, newItem3);
                                QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                                tableWidget->setItem(0, 3, newItem4);
                                QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_strquantity);
                                tableWidget->setItem(0, 4, newItem5);
                                int k=0;
                                for(int i=0;i<Books.size();i++)
                                {
                                    for(int j=0;j<Books[i].m_bookdatagroup.size();j++)
                                    {
                                        if(Books[i].m_bookdatagroup[j].m_bflag==1)
                                        {
                                            k++;
                                            break;
                                        }
                                        else
                                        {
                                        }
                                    }
                                }
                                if(k!=0)
                                {
                                    QTableWidgetItem *newItem6 = new QTableWidgetItem("可借");
                                    tableWidget->setItem(0, 5, newItem6);
                                }
                                else
                                {
                                    QTableWidgetItem *newItem6 = new QTableWidgetItem("不可借");
                                    tableWidget->setItem(0, 5, newItem6);
                                }
                                QTableWidgetItem *newItem7 = new QTableWidgetItem(Books[i].m_strbooksnumber);
                                tableWidget->setItem(0, 6, newItem7);
                            }
                        }
                    }
                }
                else if(tempbooks.m_strbooksnumber!="")
                {
                    //根据出版社和书目编号查询
                    for(int i=0;i<Books.size();i++)//遍历Books寻找符合条件的书
                    {
                        if(tempbooks.m_strpress==Books[i].m_strpress&&tempbooks.m_strbooksnumber==Books[i].m_strbooksnumber)
                        {
                            Books[i].m_strquantity= QString::number(Books[i].m_nquantity);
                            tableWidget->insertRow(j);
                            Books[i].m_strpublishday = Books[i].m_publishday.toString("yyyy-MM-dd");
                            QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_strbooksname);
                            tableWidget->setItem(0, 0, newItem1);
                            QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                            tableWidget->setItem(0, 1, newItem2);
                            QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                            tableWidget->setItem(0, 2, newItem3);
                            QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                            tableWidget->setItem(0, 3, newItem4);
                            QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_strquantity);
                            tableWidget->setItem(0, 4, newItem5);
                            int k=0;
                            for(int i=0;i<Books.size();i++)
                            {
                                for(int j=0;j<Books[i].m_bookdatagroup.size();j++)
                                {
                                    if(Books[i].m_bookdatagroup[j].m_bflag==1)
                                    {
                                        k++;
                                        break;
                                    }
                                    else
                                    {
                                    }
                                }
                            }
                            if(k!=0)
                            {
                                QTableWidgetItem *newItem6 = new QTableWidgetItem("可借");
                                tableWidget->setItem(0, 5, newItem6);
                            }
                            else
                            {
                                QTableWidgetItem *newItem6 = new QTableWidgetItem("不可借");
                                tableWidget->setItem(0, 5, newItem6);
                            }
                            QTableWidgetItem *newItem7 = new QTableWidgetItem(Books[i].m_strbooksnumber);
                            tableWidget->setItem(0, 6, newItem7);
                        }
                    }
                }
                else
                {
                    //根据出版社查询
                    for(int i=0;i<Books.size();i++)//遍历Books寻找符合条件的书
                    {
                        if(tempbooks.m_strpress==Books[i].m_strpress)
                        {
                            Books[i].m_strquantity= QString::number(Books[i].m_nquantity);
                            tableWidget->insertRow(j);
                            Books[i].m_strpublishday = Books[i].m_publishday.toString("yyyy-MM-dd");
                            QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_strbooksname);
                            tableWidget->setItem(0, 0, newItem1);
                            QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                            tableWidget->setItem(0, 1, newItem2);
                            QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                            tableWidget->setItem(0, 2, newItem3);
                            QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                            tableWidget->setItem(0, 3, newItem4);
                            QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_strquantity);
                            tableWidget->setItem(0, 4, newItem5);
                            int k=0;
                            for(int i=0;i<Books.size();i++)
                            {
                                for(int j=0;j<Books[i].m_bookdatagroup.size();j++)
                                {
                                    if(Books[i].m_bookdatagroup[j].m_bflag==1)
                                    {
                                        k++;
                                        break;
                                    }
                                    else
                                    {
                                    }
                                }
                            }
                            if(k!=0)
                            {
                                QTableWidgetItem *newItem6 = new QTableWidgetItem("可借");
                                tableWidget->setItem(0, 5, newItem6);
                            }
                            else
                            {
                                QTableWidgetItem *newItem6 = new QTableWidgetItem("不可借");
                                tableWidget->setItem(0, 5, newItem6);
                            }
                            QTableWidgetItem *newItem7 = new QTableWidgetItem(Books[i].m_strbooksnumber);
                            tableWidget->setItem(0, 6, newItem7);
                        }
                    }
                }
            }
            else if(tempbooks.m_strwritername!="")
            {
                if(tempbooks.m_strbooksnumber!="")
                {
                    //根据作者名和书目编号查询
                    for(int i=0;i<Books.size();i++)//遍历Books寻找符合条件的书
                    {
                        if(tempbooks.m_strbooksname==Books[i].m_strbooksname&&tempbooks.m_strbooksnumber==Books[i].m_strbooksnumber)
                        {
                            Books[i].m_strquantity= QString::number(Books[i].m_nquantity);
                            tableWidget->insertRow(j);
                            Books[i].m_strpublishday = Books[i].m_publishday.toString("yyyy-MM-dd");
                            QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_strbooksname);
                            tableWidget->setItem(0, 0, newItem1);
                            QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                            tableWidget->setItem(0, 1, newItem2);
                            QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                            tableWidget->setItem(0, 2, newItem3);
                            QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                            tableWidget->setItem(0, 3, newItem4);
                            QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_strquantity);
                            tableWidget->setItem(0, 4, newItem5);
                            int k=0;
                            for(int i=0;i<Books.size();i++)
                            {
                                for(int j=0;j<Books[i].m_bookdatagroup.size();j++)
                                {
                                    if(Books[i].m_bookdatagroup[j].m_bflag==1)
                                    {
                                        k++;
                                        break;
                                    }
                                    else
                                    {
                                    }
                                }
                            }
                            if(k!=0)
                            {
                                QTableWidgetItem *newItem6 = new QTableWidgetItem("可借");
                                tableWidget->setItem(0, 5, newItem6);
                            }
                            else
                            {
                                QTableWidgetItem *newItem6 = new QTableWidgetItem("不可借");
                                tableWidget->setItem(0, 5, newItem6);
                            }
                            QTableWidgetItem *newItem7 = new QTableWidgetItem(Books[i].m_strbooksnumber);
                            tableWidget->setItem(0, 6, newItem7);
                        }
                    }
                }
                else
                {
                    //根据作者名查询
                    for(int i=0;i<Books.size();i++)//遍历Books寻找符合条件的书
                    {
                        if(tempbooks.m_strwritername==Books[i].m_strwritername)
                        {
                            Books[i].m_strquantity= QString::number(Books[i].m_nquantity);
                            tableWidget->insertRow(j);
                            Books[i].m_strpublishday = Books[i].m_publishday.toString("yyyy-MM-dd");
                            QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_strbooksname);
                            tableWidget->setItem(0, 0, newItem1);
                            QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                            tableWidget->setItem(0, 1, newItem2);
                            QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                            tableWidget->setItem(0, 2, newItem3);
                            QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                            tableWidget->setItem(0, 3, newItem4);
                            QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_strquantity);
                            tableWidget->setItem(0, 4, newItem5);
                            int k=0;
                            for(int i=0;i<Books.size();i++)
                            {
                                for(int j=0;j<Books[i].m_bookdatagroup.size();j++)
                                {
                                    if(Books[i].m_bookdatagroup[j].m_bflag==1)
                                    {
                                        k++;
                                        break;
                                    }
                                    else
                                    {
                                    }
                                }
                            }
                            if(k!=0)
                            {
                                QTableWidgetItem *newItem6 = new QTableWidgetItem("可借");
                                tableWidget->setItem(0, 5, newItem6);
                            }
                            else
                            {
                                QTableWidgetItem *newItem6 = new QTableWidgetItem("不可借");
                                tableWidget->setItem(0, 5, newItem6);
                            }
                            QTableWidgetItem *newItem7 = new QTableWidgetItem(Books[i].m_strbooksnumber);
                            tableWidget->setItem(0, 6, newItem7);
                        }
                    }
                }
            }
            else
            {
                if(tempbooks.m_strbooksnumber!="")
                {
                    //根据书目编号查询
                    for(int i=0;i<Books.size();i++)//遍历Books寻找符合条件的书
                    {
                        if(tempbooks.m_strbooksnumber==Books[i].m_strbooksnumber)
                        {
                            Books[i].m_strquantity= QString::number(Books[i].m_nquantity);
                            tableWidget->insertRow(j);
                            Books[i].m_strpublishday = Books[i].m_publishday.toString("yyyy-MM-dd");
                            QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_strbooksname);
                            tableWidget->setItem(0, 0, newItem1);
                            QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                            tableWidget->setItem(0, 1, newItem2);
                            QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                            tableWidget->setItem(0, 2, newItem3);
                            QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                            tableWidget->setItem(0, 3, newItem4);
                            QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_strquantity);
                            tableWidget->setItem(0, 4, newItem5);
                            int k=0;
                            for(int i=0;i<Books.size();i++)
                            {
                                for(int j=0;j<Books[i].m_bookdatagroup.size();j++)
                                {
                                    if(Books[i].m_bookdatagroup[j].m_bflag==1)
                                    {
                                        k++;
                                        break;
                                    }
                                    else
                                    {
                                    }
                                }
                            }
                            if(k!=0)
                            {
                                QTableWidgetItem *newItem6 = new QTableWidgetItem("可借");
                                tableWidget->setItem(0, 5, newItem6);
                            }
                            else
                            {
                                QTableWidgetItem *newItem6 = new QTableWidgetItem("不可借");
                                tableWidget->setItem(0, 5, newItem6);
                            }
                            QTableWidgetItem *newItem7 = new QTableWidgetItem(Books[i].m_strbooksnumber);
                            tableWidget->setItem(0, 6, newItem7);
                        }
                    }
                }
                else
                {
                    //四项都空
                    QMessageBox messageBox;//弹一个窗口显示文字
                    messageBox.setWindowTitle("结果");
                    messageBox.setText("请输入信息后查询");
                    messageBox.exec();
                }
            }
        }
        tableWidget->show();//显示表格
    }
}


void MainWindow::on_pushButton_12_clicked()/*浏览书籍*/
{
    BrowseBook dlgSignup(this);
    int ret=dlgSignup.exec();
    class Book tempbook;
    tempbook.m_strbookname=dlgSignup.bookname();
    tempbook.m_strbooksnumber=dlgSignup.booksnumber();
    int m=0;//计数
    if(ret==BrowseBook::Accepted)
    {
        for(int i=0;i<Books.size();i++)//在Books里找一个书名一样的
        {
            if(Books[i].m_strbooksname==tempbook.m_strbookname&&tempbook.m_strbooksnumber==Books[i].m_strbooksnumber)
            {
                QTableWidget *tableWidget = new QTableWidget(Books[i].m_bookdatagroup.size(), 9);
                tableWidget->setHorizontalHeaderLabels({"书名","作者名","出版日期","出版社","书目编号","书登记号","是否可借","借出日期","借书证号"});
                for(int j=0;j<Books[i].m_bookdatagroup.size();j++)//在相同书名里的都显示出来
                {
                    QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strbookname);
                    tableWidget->setItem(j, 0, newItem1);
                    QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                    tableWidget->setItem(j, 1, newItem2);
                    QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                    tableWidget->setItem(j, 2, newItem3);
                    QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                    tableWidget->setItem(j, 3, newItem4);
                    Books[i].m_strquantity= QString::number(Books[i].m_nquantity);
                    QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strbooksnumber);
                    tableWidget->setItem(j, 4, newItem5);
                    QTableWidgetItem *newItem6 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strchecknumber);
                    tableWidget->setItem(j, 5, newItem6);
                    if(Books[i].m_bookdatagroup[j].m_bflag==0)
                    {
                        QTableWidgetItem *newItem7 = new QTableWidgetItem("不可借");
                        tableWidget->setItem(j, 6, newItem7);
                        QString g_strpublishday = Books[i].m_bookdatagroup[j].m_borrowday.toString("yyyy-MM-dd");
                        QTableWidgetItem *newItem8 = new QTableWidgetItem(g_strpublishday);
                        tableWidget->setItem(j, 7, newItem8);
                        QTableWidgetItem *newItem9 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strcardnumber);
                        tableWidget->setItem(j, 8, newItem9);
                    }
                    else if(Books[i].m_bookdatagroup[j].m_bflag!=0)
                    {
                        QTableWidgetItem *newItem7 = new QTableWidgetItem("可借");
                        tableWidget->setItem(j, 6, newItem7);
                        QTableWidgetItem *newItem8 = new QTableWidgetItem("");
                        tableWidget->setItem(j, 7, newItem8);
                        QTableWidgetItem *newItem9 = new QTableWidgetItem("");
                        tableWidget->setItem(j, 8, newItem9);
                    }
                    else
                    {
                        QTableWidgetItem *newItem7 = new QTableWidgetItem("出错");
                        tableWidget->setItem(j, 6, newItem7);
                    }
                    QTableWidgetItem *newItem9 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strcardnumber);
                    tableWidget->setItem(j, 8, newItem9);
                }
                tableWidget->show();//显示表格
                m++;
            }
            else
            {
            }
        }
        if(m==0)
        {
            QMessageBox messageBox;//弹一个窗口显示文字
            messageBox.setWindowTitle("结果");
            messageBox.setText("请输入信息后查询");
            messageBox.exec();
        }
    }
}


void MainWindow::on_pushButton_11_clicked()/*查询书籍*/
{//原理和查询图书相同
    SeekBook dlgSignup(this);
    int ret=dlgSignup.exec();
    class Book tempbook;
    tempbook.m_strbookname=dlgSignup.bookname();
    tempbook.m_strcardnumber=dlgSignup.cardnumber();
    tempbook.m_strchecknumber=dlgSignup.checknumber();//读取内容
    int n=0;//用于产生多行表格而使不同书目下的同一个位置的书互不影响
    if(ret==SeekBook::Accepted)//2的n次方减一
    {
        QTableWidget *tableWidget = new QTableWidget(0, 9);
        tableWidget->setHorizontalHeaderLabels({"书名","作者名","出版日期","出版社","书目编号","书登记号","是否可借","借出日期","借书证号"});
        if(tempbook.m_strbookname!="")
        {
            if(tempbook.m_strchecknumber!="")
            {
                if(tempbook.m_strcardnumber!="")
                {
                    //根据三项查询
                    for(int i=0;i<Books.size();i++)
                    {
                        for(int j=0;j<Books[i].m_bookdatagroup.size();j++)//搜到对应的书
                        {
                            if(tempbook.m_strchecknumber==Books[i].m_bookdatagroup[j].m_strchecknumber&&tempbook.m_strcardnumber==Books[i].m_bookdatagroup[j].m_strcardnumber&&tempbook.m_strbookname==Books[i].m_bookdatagroup[j].m_strbookname)
                            {
                                tableWidget->insertRow(n);
                                QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strbookname);
                                tableWidget->setItem(n, 0, newItem1);
                                QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                                tableWidget->setItem(n, 1, newItem2);
                                QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                                tableWidget->setItem(n, 2, newItem3);
                                QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                                tableWidget->setItem(n, 3, newItem4);
                                QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strbooksnumber);
                                tableWidget->setItem(n, 4, newItem5);
                                QTableWidgetItem *newItem6 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strchecknumber);
                                tableWidget->setItem(n, 5, newItem6);
                                if(Books[i].m_bookdatagroup[j].m_bflag==0)
                                {
                                    QTableWidgetItem *newItem7 = new QTableWidgetItem("不可借");
                                    tableWidget->setItem(n, 6, newItem7);
                                    QString g_strpublishday = Books[i].m_bookdatagroup[j].m_borrowday.toString("yyyy-MM-dd");
                                    QTableWidgetItem *newItem8 = new QTableWidgetItem(g_strpublishday);
                                    tableWidget->setItem(n, 7, newItem8);
                                    QTableWidgetItem *newItem9 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strcardnumber);
                                    tableWidget->setItem(n, 8, newItem9);
                                }
                                else if(Books[i].m_bookdatagroup[j].m_bflag!=0)
                                {
                                    QTableWidgetItem *newItem7 = new QTableWidgetItem("可借");
                                    tableWidget->setItem(n, 6, newItem7);
                                    QTableWidgetItem *newItem8 = new QTableWidgetItem("");
                                    tableWidget->setItem(n, 7, newItem8);
                                    QTableWidgetItem *newItem9 = new QTableWidgetItem("");
                                    tableWidget->setItem(n, 8, newItem9);
                                }
                                else
                                {
                                    QTableWidgetItem *newItem7 = new QTableWidgetItem("出错");
                                    tableWidget->setItem(n, 6, newItem7);
                                }
                                QTableWidgetItem *newItem9 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strcardnumber);
                                tableWidget->setItem(n, 8, newItem9);
                                n++;
                            }

                        }
                    }
                }
                else
                {
                    //根据除了借书证号的两项查询
                    for(int i=0;i<Books.size();i++)
                    {
                        for(int j=0;j<Books[i].m_bookdatagroup.size();j++)//搜到对应的书
                        {
                            if(tempbook.m_strchecknumber==Books[i].m_bookdatagroup[j].m_strchecknumber&&tempbook.m_strbookname==Books[i].m_bookdatagroup[j].m_strbookname)
                            {
                                tableWidget->insertRow(n);
                                QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strbookname);
                                tableWidget->setItem(n, 0, newItem1);
                                QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                                tableWidget->setItem(n, 1, newItem2);
                                QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                                tableWidget->setItem(n, 2, newItem3);
                                QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                                tableWidget->setItem(n, 3, newItem4);
                                QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strbooksnumber);
                                tableWidget->setItem(n, 4, newItem5);
                                QTableWidgetItem *newItem6 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strchecknumber);
                                tableWidget->setItem(n, 5, newItem6);
                                if(Books[i].m_bookdatagroup[j].m_bflag==0)
                                {
                                    QTableWidgetItem *newItem7 = new QTableWidgetItem("不可借");
                                    tableWidget->setItem(n, 6, newItem7);
                                    QString g_strpublishday = Books[i].m_bookdatagroup[j].m_borrowday.toString("yyyy-MM-dd");
                                    QTableWidgetItem *newItem8 = new QTableWidgetItem(g_strpublishday);
                                    tableWidget->setItem(n, 7, newItem8);
                                    QTableWidgetItem *newItem9 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strcardnumber);
                                    tableWidget->setItem(n, 8, newItem9);
                                }
                                else if(Books[i].m_bookdatagroup[j].m_bflag!=0)
                                {
                                    QTableWidgetItem *newItem7 = new QTableWidgetItem("可借");
                                    tableWidget->setItem(n, 6, newItem7);
                                    QTableWidgetItem *newItem8 = new QTableWidgetItem("");
                                    tableWidget->setItem(n, 7, newItem8);
                                    QTableWidgetItem *newItem9 = new QTableWidgetItem("");
                                    tableWidget->setItem(n, 8, newItem9);
                                }
                                else
                                {
                                    QTableWidgetItem *newItem7 = new QTableWidgetItem("出错");
                                    tableWidget->setItem(n, 6, newItem7);
                                }
                                QTableWidgetItem *newItem9 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strcardnumber);
                                tableWidget->setItem(n, 8, newItem9);
                                n++;
                            }
                        }
                    }
                }
            }
            else
            {
                if(tempbook.m_strcardnumber!="")
                {
                    //根据除了登记号的两项查询
                    for(int i=0;i<Books.size();i++)
                    {
                        for(int j=0;j<Books[i].m_bookdatagroup.size();j++)//搜到对应的书
                        {
                            if(tempbook.m_strcardnumber==Books[i].m_bookdatagroup[j].m_strcardnumber&&tempbook.m_strbookname==Books[i].m_bookdatagroup[j].m_strbookname)
                            {
                                tableWidget->insertRow(n);
                                QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strbookname);
                                tableWidget->setItem(n, 0, newItem1);
                                QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                                tableWidget->setItem(n, 1, newItem2);
                                QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                                tableWidget->setItem(n, 2, newItem3);
                                QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                                tableWidget->setItem(n, 3, newItem4);
                                QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strbooksnumber);
                                tableWidget->setItem(n, 4, newItem5);
                                QTableWidgetItem *newItem6 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strchecknumber);
                                tableWidget->setItem(n, 5, newItem6);
                                if(Books[i].m_bookdatagroup[j].m_bflag==0)
                                {
                                    QTableWidgetItem *newItem7 = new QTableWidgetItem("不可借");
                                    tableWidget->setItem(n, 6, newItem7);
                                    QString g_strpublishday = Books[i].m_bookdatagroup[j].m_borrowday.toString("yyyy-MM-dd");
                                    QTableWidgetItem *newItem8 = new QTableWidgetItem(g_strpublishday);
                                    tableWidget->setItem(n, 7, newItem8);
                                    QTableWidgetItem *newItem9 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strcardnumber);
                                    tableWidget->setItem(n, 8, newItem9);
                                }
                                else if(Books[i].m_bookdatagroup[j].m_bflag!=0)
                                {
                                    QTableWidgetItem *newItem7 = new QTableWidgetItem("可借");
                                    tableWidget->setItem(n, 6, newItem7);
                                    QTableWidgetItem *newItem8 = new QTableWidgetItem("");
                                    tableWidget->setItem(n, 7, newItem8);
                                    QTableWidgetItem *newItem9 = new QTableWidgetItem("");
                                    tableWidget->setItem(n, 8, newItem9);
                                }
                                else
                                {
                                    QTableWidgetItem *newItem7 = new QTableWidgetItem("出错");
                                    tableWidget->setItem(n, 6, newItem7);
                                }
                                QTableWidgetItem *newItem9 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strcardnumber);
                                tableWidget->setItem(n, 8, newItem9);
                                n++;
                            }
                        }
                    }
                }
                else
                {
                    //根据书名查询
                    for(int i=0;i<Books.size();i++)
                    {
                        for(int j=0;j<Books[i].m_bookdatagroup.size();j++)
                        {
                            if(Books[i].m_bookdatagroup[j].m_strbookname==tempbook.m_strbookname)
                            {
                                tableWidget->insertRow(n);
                                QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strbookname);
                                tableWidget->setItem(n, 0, newItem1);
                                QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                                tableWidget->setItem(n, 1, newItem2);
                                QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                                tableWidget->setItem(n, 2, newItem3);
                                QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                                tableWidget->setItem(n, 3, newItem4);
                                QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strbooksnumber);
                                tableWidget->setItem(n, 4, newItem5);
                                QTableWidgetItem *newItem6 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strchecknumber);
                                tableWidget->setItem(n, 5, newItem6);
                                if(Books[i].m_bookdatagroup[j].m_bflag==0)
                                {
                                    QTableWidgetItem *newItem7 = new QTableWidgetItem("不可借");
                                    tableWidget->setItem(n, 6, newItem7);
                                    QString g_strpublishday = Books[i].m_bookdatagroup[j].m_borrowday.toString("yyyy-MM-dd");
                                    QTableWidgetItem *newItem8 = new QTableWidgetItem(g_strpublishday);
                                    tableWidget->setItem(n, 7, newItem8);
                                    QTableWidgetItem *newItem9 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strcardnumber);
                                    tableWidget->setItem(n, 8, newItem9);
                                }
                                else if(Books[i].m_bookdatagroup[j].m_bflag!=0)
                                {
                                    QTableWidgetItem *newItem7 = new QTableWidgetItem("可借");
                                    tableWidget->setItem(n, 6, newItem7);
                                    QTableWidgetItem *newItem8 = new QTableWidgetItem("");
                                    tableWidget->setItem(n, 7, newItem8);
                                    QTableWidgetItem *newItem9 = new QTableWidgetItem("");
                                    tableWidget->setItem(n, 8, newItem9);
                                }
                                else
                                {
                                    QTableWidgetItem *newItem7 = new QTableWidgetItem("出错");
                                    tableWidget->setItem(n, 6, newItem7);
                                }
                                QTableWidgetItem *newItem9 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strcardnumber);
                                tableWidget->setItem(n, 8, newItem9);
                                n++;
                            }
                        }
                    }
                }
            }
        }
        else
        {
            if(tempbook.m_strchecknumber!="")
            {
                if(tempbook.m_strcardnumber!="")
                {
                    //根据除了书名的两项查询
                    for(int i=0;i<Books.size();i++)
                    {
                        for(int j=0;j<Books[i].m_bookdatagroup.size();j++)//搜到对应的书
                        {
                            if(tempbook.m_strchecknumber==Books[i].m_bookdatagroup[j].m_strchecknumber&&tempbook.m_strcardnumber==Books[i].m_bookdatagroup[j].m_strcardnumber)
                            {
                                tableWidget->insertRow(n);
                                QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strbookname);
                                tableWidget->setItem(n, 0, newItem1);
                                QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                                tableWidget->setItem(n, 1, newItem2);
                                QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                                tableWidget->setItem(n, 2, newItem3);
                                QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                                tableWidget->setItem(n, 3, newItem4);
                                QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strbooksnumber);
                                tableWidget->setItem(n, 4, newItem5);
                                QTableWidgetItem *newItem6 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strchecknumber);
                                tableWidget->setItem(n, 5, newItem6);
                                if(Books[i].m_bookdatagroup[j].m_bflag==0)
                                {
                                    QTableWidgetItem *newItem7 = new QTableWidgetItem("不可借");
                                    tableWidget->setItem(n, 6, newItem7);
                                    QString g_strpublishday = Books[i].m_bookdatagroup[j].m_borrowday.toString("yyyy-MM-dd");
                                    QTableWidgetItem *newItem8 = new QTableWidgetItem(g_strpublishday);
                                    tableWidget->setItem(n, 7, newItem8);
                                    QTableWidgetItem *newItem9 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strcardnumber);
                                    tableWidget->setItem(n, 8, newItem9);
                                }
                                else if(Books[i].m_bookdatagroup[j].m_bflag!=0)
                                {
                                    QTableWidgetItem *newItem7 = new QTableWidgetItem("可借");
                                    tableWidget->setItem(n, 6, newItem7);
                                    QTableWidgetItem *newItem8 = new QTableWidgetItem("");
                                    tableWidget->setItem(n, 7, newItem8);
                                    QTableWidgetItem *newItem9 = new QTableWidgetItem("");
                                    tableWidget->setItem(n, 8, newItem9);
                                }
                                else
                                {
                                    QTableWidgetItem *newItem7 = new QTableWidgetItem("出错");
                                    tableWidget->setItem(n, 6, newItem7);
                                }
                                QTableWidgetItem *newItem9 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strcardnumber);
                                tableWidget->setItem(n, 8, newItem9);
                                n++;
                            }
                        }
                    }
                }
                else
                {
                    //根据书登记号查询
                    for(int i=0;i<Books.size();i++)
                    {
                        for(int j=0;j<Books[i].m_bookdatagroup.size();j++)
                        {
                            if(tempbook.m_strchecknumber==Books[i].m_bookdatagroup[j].m_strchecknumber)
                            {
                                tableWidget->insertRow(n);
                                QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strbookname);
                                tableWidget->setItem(n, 0, newItem1);
                                QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                                tableWidget->setItem(n, 1, newItem2);
                                QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                                tableWidget->setItem(n, 2, newItem3);
                                QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                                tableWidget->setItem(n, 3, newItem4);
                                QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strbooksnumber);
                                tableWidget->setItem(n, 4, newItem5);
                                QTableWidgetItem *newItem6 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strchecknumber);
                                tableWidget->setItem(n, 5, newItem6);
                                if(Books[i].m_bookdatagroup[j].m_bflag==0)
                                {
                                    QTableWidgetItem *newItem7 = new QTableWidgetItem("不可借");
                                    tableWidget->setItem(n, 6, newItem7);
                                    QString g_strpublishday = Books[i].m_bookdatagroup[j].m_borrowday.toString("yyyy-MM-dd");
                                    QTableWidgetItem *newItem8 = new QTableWidgetItem(g_strpublishday);
                                    tableWidget->setItem(n, 7, newItem8);
                                    QTableWidgetItem *newItem9 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strcardnumber);
                                    tableWidget->setItem(n, 8, newItem9);
                                }
                                else if(Books[i].m_bookdatagroup[j].m_bflag!=0)
                                {
                                    QTableWidgetItem *newItem7 = new QTableWidgetItem("可借");
                                    tableWidget->setItem(n, 6, newItem7);
                                    QTableWidgetItem *newItem8 = new QTableWidgetItem("");
                                    tableWidget->setItem(n, 7, newItem8);
                                    QTableWidgetItem *newItem9 = new QTableWidgetItem("");
                                    tableWidget->setItem(n, 8, newItem9);
                                }
                                else
                                {
                                    QTableWidgetItem *newItem7 = new QTableWidgetItem("出错");
                                    tableWidget->setItem(n, 6, newItem7);
                                }
                                QTableWidgetItem *newItem9 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strcardnumber);
                                tableWidget->setItem(n, 8, newItem9);
                                n++;
                            }
                        }
                    }
                }
            }
            else
            {
                if(tempbook.m_strcardnumber!="")
                {
                    //根据借书证号查询
                    for(int i=0;i<Books.size();i++)
                    {
                        for(int j=0;j<Books[i].m_bookdatagroup.size();j++)//搜到对应的书
                        {
                            if(tempbook.m_strcardnumber==Books[i].m_bookdatagroup[j].m_strcardnumber)
                            {
                                tableWidget->insertRow(n);
                                QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strbookname);
                                tableWidget->setItem(n, 0, newItem1);
                                QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
                                tableWidget->setItem(n, 1, newItem2);
                                QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
                                tableWidget->setItem(n, 2, newItem3);
                                QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
                                tableWidget->setItem(n, 3, newItem4);
                                QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strbooksnumber);
                                tableWidget->setItem(n, 4, newItem5);
                                QTableWidgetItem *newItem6 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strchecknumber);
                                tableWidget->setItem(n, 5, newItem6);
                                if(Books[i].m_bookdatagroup[j].m_bflag==0)
                                {
                                    QTableWidgetItem *newItem7 = new QTableWidgetItem("不可借");
                                    tableWidget->setItem(n, 6, newItem7);
                                    QString g_strpublishday = Books[i].m_bookdatagroup[j].m_borrowday.toString("yyyy-MM-dd");
                                    QTableWidgetItem *newItem8 = new QTableWidgetItem(g_strpublishday);
                                    tableWidget->setItem(n, 7, newItem8);
                                    QTableWidgetItem *newItem9 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strcardnumber);
                                    tableWidget->setItem(n, 8, newItem9);
                                }
                                else if(Books[i].m_bookdatagroup[j].m_bflag!=0)
                                {
                                    QTableWidgetItem *newItem7 = new QTableWidgetItem("可借");
                                    tableWidget->setItem(n, 6, newItem7);
                                    QTableWidgetItem *newItem8 = new QTableWidgetItem("");
                                    tableWidget->setItem(n, 7, newItem8);
                                    QTableWidgetItem *newItem9 = new QTableWidgetItem("");
                                    tableWidget->setItem(n, 8, newItem9);
                                }
                                else
                                {
                                    QTableWidgetItem *newItem7 = new QTableWidgetItem("出错");
                                    tableWidget->setItem(n, 6, newItem7);
                                }
                                QTableWidgetItem *newItem9 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strcardnumber);
                                tableWidget->setItem(n, 8, newItem9);
                                n++;
                            }
                        }
                    }
                }
                else
                {
                    //三项全空
                    QMessageBox messageBox;//弹一个窗口显示文字
                    messageBox.setWindowTitle("结果");
                    messageBox.setText("请输入信息后查询");
                    messageBox.exec();
                }
            }
        }
        tableWidget->show();//显示表格
    }
}


void MainWindow::on_pushButton_6_clicked()/*借书*/
{
    BorrowBook dlgSignup(this);
    int ret=dlgSignup.exec();
    class Book tempbook;
    if(ret==BorrowBook::Accepted)
    {
        QDate g_currentday = QDate::currentDate();
        tempbook.m_borrowday=g_currentday;
        tempbook.m_strcardnumber=0;//等待修改
        tempbook.m_strbookname=dlgSignup.bookname();
        tempbook.m_strchecknumber=dlgSignup.checknumber();
        int m=0;//计数
        for(int i=0;i<Books.size();i++)
        {
            for(int j=0;j<Books[i].m_bookdatagroup.size();j++)
            {
                if(((Books[i].m_bookdatagroup[j].m_strbookname==tempbook.m_strbookname)&&(Books[i].m_bookdatagroup[j].m_strchecknumber==tempbook.m_strchecknumber))&&Books[i].m_bookdatagroup[j].m_bflag==1)
                {
                    CardNumber dlgSignup(this);
                    int ret =dlgSignup.exec();
                    if(ret==CardNumber::Accepted)
                    {
                        tempbook.m_strcardnumber=dlgSignup.cardnumber();
                        tempbook.m_bflag=0;//修改为不可借出
                        tempbook.m_strbooksnumber=Books[i].m_strbooksnumber;
                        Book.push_back(tempbook);//将book变为已经借出的书的序列
                        Books[i].m_bookdatagroup.replace(j,tempbook);//将修改好的书籍存回去进行替换
                        Books[i].m_nquantity--;
                        m++;
                        QMessageBox messageBox;//弹一个窗口显示文字
                        messageBox.setWindowTitle("结果");
                        messageBox.setText("已经为您成功借出");
                        messageBox.exec();
                    }
                    break;
                }
            }
        }
        if(m==0)
        {
            QMessageBox messageBox;
            messageBox.setWindowTitle("结果");
            messageBox.setText("未能成功借出");
            messageBox.exec();
        }
    }
}


void MainWindow::on_pushButton_7_clicked()/*还书*/
{
    ReturnBook dlgSignup(this);
    int ret=dlgSignup.exec();
    if(ret==ReturnBook::Accepted)
    {
        class Book tempbook;
        tempbook.m_strchecknumber=dlgSignup.checknumber();
        tempbook.m_strbookname=dlgSignup.bookname();
        tempbook.m_strcardnumber=dlgSignup.cardnumber();
        tempbook.m_bflag=1;
        int m=0;//记录搜索次数
        for(int i=0;i<Book.size();i++)
        {
            if(tempbook.m_strchecknumber==Book[i].m_strchecknumber&&tempbook.m_strcardnumber==Book[i].m_strcardnumber)
            {
                QMessageBox messageBox;//弹一个窗口显示文字
                messageBox.setWindowTitle("结果");
                messageBox.setText("已经为您成功还书");
                messageBox.exec();
                Book.remove(i);
                m++;
                break;
            }
        }//对已经借出的书的序列进行修改
        if (m==0)
        {
            QMessageBox messageBox;//弹一个窗口显示文字
            messageBox.setWindowTitle("结果");
            messageBox.setText("未能成功还书");
            messageBox.exec();
        }
        for(int j=0;j<Books.size();j++)
        {
            for(int l=0;l<Books[j].m_bookdatagroup.size();l++)
            {
                if(Books[j].m_bookdatagroup[l].m_strchecknumber==tempbook.m_strchecknumber&&tempbook.m_strcardnumber==Books[j].m_bookdatagroup[l].m_strcardnumber)
                {
                    tempbook.m_strcardnumber="";
                    tempbook.m_strbooksnumber=Books[j].m_bookdatagroup[l].m_strbooksnumber;
                    Books[j].m_nquantity++;
                    Books[j].m_bookdatagroup.replace(l,tempbook);
                }
            }
        }//对图书馆里的书的序列进行修改
    }
}
void MainWindow::onOkButtonClicked()
{//输入借书证

}

void MainWindow::on_pushButton_13_clicked()//浏览全部书籍
{
    QTableWidget *tableWidget = new QTableWidget(0, 9);
    tableWidget->setHorizontalHeaderLabels({"书名","作者名","出版日期","出版社","书目编号","书登记号","是否可借","借出日期","借书证号"});
    for(int i=0;i<Books.size();i++)
    {
        for(int j=0;j<Books[i].m_bookdatagroup.size();j++)//在相同书名里的都显示出来
        {
            tableWidget->insertRow(j);
            QTableWidgetItem *newItem1 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strbookname);
            tableWidget->setItem(j, 0, newItem1);
            QTableWidgetItem *newItem2 = new QTableWidgetItem(Books[i].m_strwritername);
            tableWidget->setItem(j, 1, newItem2);
            QTableWidgetItem *newItem3 = new QTableWidgetItem(Books[i].m_strpublishday);
            tableWidget->setItem(j, 2, newItem3);
            QTableWidgetItem *newItem4 = new QTableWidgetItem(Books[i].m_strpress);
            tableWidget->setItem(j, 3, newItem4);
            Books[i].m_strquantity= QString::number(Books[i].m_nquantity);
            QTableWidgetItem *newItem5 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strbooksnumber);
            tableWidget->setItem(j, 4, newItem5);
            QTableWidgetItem *newItem6 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strchecknumber);
            tableWidget->setItem(j, 5, newItem6);
            if(Books[i].m_bookdatagroup[j].m_bflag==0)
            {
                QTableWidgetItem *newItem7 = new QTableWidgetItem("不可借");
                tableWidget->setItem(j, 6, newItem7);
                QString g_strpublishday = Books[i].m_bookdatagroup[j].m_borrowday.toString("yyyy-MM-dd");
                QTableWidgetItem *newItem8 = new QTableWidgetItem(g_strpublishday);
                tableWidget->setItem(j, 7, newItem8);
                QTableWidgetItem *newItem9 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strcardnumber);
                tableWidget->setItem(j, 8, newItem9);
            }
            else if(Books[i].m_bookdatagroup[j].m_bflag!=0)
            {
                QTableWidgetItem *newItem7 = new QTableWidgetItem("可借");
                tableWidget->setItem(j, 6, newItem7);
                QTableWidgetItem *newItem8 = new QTableWidgetItem("");
                tableWidget->setItem(j, 7, newItem8);
                QTableWidgetItem *newItem9 = new QTableWidgetItem("");
                tableWidget->setItem(j, 8, newItem9);
            }
            else
            {
                QTableWidgetItem *newItem7 = new QTableWidgetItem("出错");
                tableWidget->setItem(j, 6, newItem7);
            }
            QTableWidgetItem *newItem9 = new QTableWidgetItem(Books[i].m_bookdatagroup[j].m_strcardnumber);
            tableWidget->setItem(j, 8, newItem9);
        }
    }
    tableWidget->show();//显示表格
}

