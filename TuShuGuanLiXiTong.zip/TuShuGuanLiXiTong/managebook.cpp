#include "managebook.h"
#include "ui_managebook.h"

ManageBook::ManageBook(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::ManageBook)
{
    ui->setupUi(this);
}

ManageBook::~ManageBook()
{
    delete ui;
}

QString ManageBook::bookname()
{
    return (ui->textEdit->toPlainText());
}

QString ManageBook::checknumber()
{
    return (ui->textEdit_2->toPlainText());
}

void ManageBook::on_buttonBox_accepted()
{

}

