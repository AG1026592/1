#ifndef MANAGEBOOK_H
#define MANAGEBOOK_H

#include <QDialog>

namespace Ui {
class ManageBook;
}

class ManageBook : public QDialog
{
    Q_OBJECT

public:
    explicit ManageBook(QWidget *parent = nullptr);
    ~ManageBook();
    QString bookname();
    QString checknumber();
private slots:
    void on_buttonBox_accepted();

private:
    Ui::ManageBook *ui;
};

#endif // MANAGEBOOK_H
