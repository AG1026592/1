#include "managebooks.h"
#include "ui_managebooks.h"

ManageBooks::ManageBooks(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::ManageBooks)
{
    ui->setupUi(this);
}

ManageBooks::~ManageBooks()
{
    delete ui;
}

QString ManageBooks::booksname()
{
    return (ui->textEdit->toPlainText());
}
QString ManageBooks::booksnumber()
{
    return (ui->textEdit_2->toPlainText());
}

void ManageBooks::on_buttonBox_accepted()
{

}

