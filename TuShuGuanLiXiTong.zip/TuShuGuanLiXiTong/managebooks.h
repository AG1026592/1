#ifndef MANAGEBOOKS_H
#define MANAGEBOOKS_H

#include <QDialog>

namespace Ui {
class ManageBooks;
}

class ManageBooks : public QDialog
{
    Q_OBJECT

public:
    explicit ManageBooks(QWidget *parent = nullptr);
    ~ManageBooks();
    QString m_strbooksname;
    QString booksname();
    QString booksnumber();
private slots:
    void on_buttonBox_accepted();

private:
    Ui::ManageBooks *ui;
};

#endif // MANAGEBOOKS_H
