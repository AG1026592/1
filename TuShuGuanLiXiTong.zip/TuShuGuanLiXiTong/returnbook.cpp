#include "returnbook.h"
#include "ui_returnbook.h"

ReturnBook::ReturnBook(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::ReturnBook)
{
    ui->setupUi(this);
}

ReturnBook::~ReturnBook()
{
    delete ui;
}

void ReturnBook::on_buttonBox_accepted()
{

}
QString ReturnBook::bookname()
{
    return (ui->textEdit->toPlainText());
}
QString ReturnBook::checknumber()
{
    return (ui->textEdit_2->toPlainText());
}
QString ReturnBook::cardnumber()
{
    return (ui->textEdit_3->toPlainText());
}
