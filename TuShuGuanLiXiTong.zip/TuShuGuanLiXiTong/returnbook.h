#ifndef RETURNBOOK_H
#define RETURNBOOK_H

#include <QDialog>

namespace Ui {
class ReturnBook;
}

class ReturnBook : public QDialog
{
    Q_OBJECT

public:
    explicit ReturnBook(QWidget *parent = nullptr);
    ~ReturnBook();
    QString m_strbookname;//书名
    QString m_strchecknumber;//书登记号
    QString m_strcardnumber;
    QString bookname();
    QString checknumber();
    QString cardnumber();
private slots:
    void on_buttonBox_accepted();

private:
    Ui::ReturnBook *ui;
};

#endif // RETURNBOOK_H
