#include "seekbook.h"
#include "ui_seekbook.h"

SeekBook::SeekBook(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::SeekBook)
{
    ui->setupUi(this);
}

SeekBook::~SeekBook()
{
    delete ui;
}


QString SeekBook::checknumber()
{
    return (ui->textEdit_3->toPlainText());
}

QString SeekBook::cardnumber()
{
    return (ui->textEdit_4->toPlainText());
}
QString SeekBook::bookname()
{
    return (ui->textEdit->toPlainText());
}

void SeekBook::on_buttonBox_accepted()
{

}

