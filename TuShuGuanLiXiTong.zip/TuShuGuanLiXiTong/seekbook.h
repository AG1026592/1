#ifndef SEEKBOOK_H
#define SEEKBOOK_H

#include <QDialog>

namespace Ui {
class SeekBook;
}

class SeekBook : public QDialog
{
    Q_OBJECT

public:
    explicit SeekBook(QWidget *parent = nullptr);
    ~SeekBook();
    QString cardnumber();//借书证号
    QString bookname();//书目名称
    QString checknumber();//书登记号
private slots:
    void on_buttonBox_accepted();

private:
    Ui::SeekBook *ui;
};

#endif // SEEKBOOK_H
