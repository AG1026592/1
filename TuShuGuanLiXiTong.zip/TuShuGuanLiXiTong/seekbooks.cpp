#include "seekbooks.h"
#include "ui_seekbooks.h"

SeekBooks::SeekBooks(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::SeekBooks)
{
    ui->setupUi(this);
}

SeekBooks::~SeekBooks()
{
    delete ui;
}
QString  SeekBooks::booksname()
{
    return (ui->textEdit->toPlainText());
}

QString  SeekBooks::booksnumber()
{
    return (ui->textEdit_2->toPlainText());
}

QString  SeekBooks::writername()
{
    return (ui->textEdit_3->toPlainText());
}

QString  SeekBooks::press()
{
    return (ui->textEdit_4->toPlainText());
}

void SeekBooks::on_buttonBox_accepted()
{

}

