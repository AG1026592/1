#ifndef SEEKBOOKS_H
#define SEEKBOOKS_H

#include <QDialog>

namespace Ui {
class SeekBooks;
}

class SeekBooks : public QDialog
{
    Q_OBJECT

public:
    explicit SeekBooks(QWidget *parent = nullptr);
    ~SeekBooks();
    QString booksname();//书名
    QString booksnumber();//书编号
    QString writername();//作者名
    QString press();//出版社
private slots:
    void on_buttonBox_accepted();

private:
    Ui::SeekBooks *ui;
};

#endif // SEEKBOOKS_H
